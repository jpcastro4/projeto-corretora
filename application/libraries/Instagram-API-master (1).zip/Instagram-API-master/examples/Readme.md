## Examples

### CLI scripts:

- checkpoint.php
- registrationTool.php

CLI means Command Line Interface, not for webserver, run these scripts in Terminal, shell, cmd...


### Ready to run:

- PaginationExample.php
- uploadPhoto.php
- uploadVideo.php

In these examples, you need to edit it and add your data.
