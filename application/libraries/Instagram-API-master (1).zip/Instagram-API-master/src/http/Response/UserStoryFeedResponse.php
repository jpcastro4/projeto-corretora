<?php

namespace InstagramAPI;

class UserStoryFeedResponse extends Response
{
    public $broadcast;

    /**
     * @var Reel
     */
    public $reel;
}
