<?php

namespace InstagramAPI;

class UploadPhotoResponse extends Response
{
    public $upload_id;
}
