<?php

namespace InstagramAPI;

class SyncResponse extends Response
{
    /**
     * @var Experiment[]
     */
    public $experiments;
}
