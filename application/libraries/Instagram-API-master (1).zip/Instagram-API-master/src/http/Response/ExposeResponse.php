<?php

namespace InstagramAPI;

class ExposeResponse extends Response
{
}
