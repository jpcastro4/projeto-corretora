<?php

namespace InstagramAPI;

class ChangePasswordResponse extends Response
{
}
