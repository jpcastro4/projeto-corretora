<?php

namespace InstagramAPI;

class FriendshipResponse extends Response
{
    /**
     * @var FriendshipStatus
     */
    public $friendship_status;
}
