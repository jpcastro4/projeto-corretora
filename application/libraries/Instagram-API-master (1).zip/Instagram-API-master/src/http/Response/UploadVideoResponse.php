<?php

namespace InstagramAPI;

class UploadVideoResponse extends Response
{
    public $upload_id;
    public $message = null;
}
