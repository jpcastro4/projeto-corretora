<?php

namespace InstagramAPI;

class MediaInsightsResponse extends Response
{
    /**
     * @var MediaInsights[]
     */
    public $media_organic_insights;
}
