<?php

namespace InstagramAPI;

class FBSearchResponse extends Response
{
    public $has_more;
    public $hashtags;
    public $users;
    public $places;
}
