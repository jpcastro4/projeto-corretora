<?php

namespace InstagramAPI;

class GeoMediaResponse extends Response
{
    public $geo_media;
}
