<?php

namespace InstagramAPI;

class InsightsResponse extends Response
{
    /**
     * @var Insights[]
     */
    public $instagram_user;
}
