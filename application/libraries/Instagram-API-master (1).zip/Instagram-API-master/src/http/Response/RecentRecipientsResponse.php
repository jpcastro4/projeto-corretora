<?php

namespace InstagramAPI;

class RecentRecipientsResponse extends Response
{
    public $expiration_interval;
    public $recent_recipients;
}
