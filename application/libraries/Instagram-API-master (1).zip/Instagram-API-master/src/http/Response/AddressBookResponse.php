<?php

namespace InstagramAPI;

class AddressBookResponse extends Response
{
    /**
     * @var Suggestion[]
     */
    public $items;
}
