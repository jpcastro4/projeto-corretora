<?php

namespace InstagramAPI;

class FriendshipsShowManyResponse extends Response
{
    /**
     * @var FriendshipStatus[]
     */
    public $friendship_statuses = [];
}
