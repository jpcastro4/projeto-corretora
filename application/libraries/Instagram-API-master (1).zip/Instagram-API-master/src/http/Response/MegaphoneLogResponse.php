<?php

namespace InstagramAPI;

class MegaphoneLogResponse extends Response
{
    public $success;
}
