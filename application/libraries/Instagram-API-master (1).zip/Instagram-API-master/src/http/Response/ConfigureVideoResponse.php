<?php

namespace InstagramAPI;

class ConfigureVideoResponse extends Response
{
    public $upload_id;
    public $media_id;
    public $image_url;
    public $video_version;
}
