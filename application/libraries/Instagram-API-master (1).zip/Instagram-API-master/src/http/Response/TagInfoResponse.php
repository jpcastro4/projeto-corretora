<?php

namespace InstagramAPI;

class TagInfoResponse extends Response
{
    public $profile;
    public $media_count;
}
