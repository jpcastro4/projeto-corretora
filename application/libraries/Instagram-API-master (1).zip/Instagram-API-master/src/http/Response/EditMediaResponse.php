<?php

namespace InstagramAPI;

class EditMediaResponse extends Response
{
    /**
     * @var Item
     */
    public $media;
}
