<?php

namespace InstagramAPI;

class SaveAndUnsaveMedia extends Response
{
}
