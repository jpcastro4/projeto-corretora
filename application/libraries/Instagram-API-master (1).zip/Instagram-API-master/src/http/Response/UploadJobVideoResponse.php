<?php

namespace InstagramAPI;

class UploadJobVideoResponse extends Response
{
    public $upload_id;
    public $video_upload_urls;
}
