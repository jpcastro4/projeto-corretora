<?php

namespace InstagramAPI;

class TagRelatedResponse extends Response
{
    public $related;
}
