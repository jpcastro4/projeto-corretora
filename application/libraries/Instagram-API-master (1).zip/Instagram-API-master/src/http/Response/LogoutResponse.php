<?php

namespace InstagramAPI;

class LogoutResponse extends Response
{
}
