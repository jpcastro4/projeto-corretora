<?php

namespace InstagramAPI;

class UsernameInfoResponse extends Response
{
    public $megaphone;
    /**
     * @var User
     */
    public $user;
}
