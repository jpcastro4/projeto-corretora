<?php

namespace InstagramAPI;

class Position extends Response
{
    public $pos1;
    public $pos2;
}
