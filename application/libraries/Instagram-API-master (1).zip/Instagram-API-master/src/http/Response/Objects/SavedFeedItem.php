<?php

namespace InstagramAPI;

class SavedFeedItem extends Response
{
    /**
     * @var Item
     */
    public $media;
}
