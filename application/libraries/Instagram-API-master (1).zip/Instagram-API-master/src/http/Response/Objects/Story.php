<?php

namespace InstagramAPI;

class Story extends Response
{
    public $pk;
    public $counts;
    public $args;
    public $type;
}
