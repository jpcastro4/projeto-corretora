<?php

namespace InstagramAPI;

class VideoVersions extends Response
{
    public $url;
    public $type;
    public $width;
    public $height;
}
