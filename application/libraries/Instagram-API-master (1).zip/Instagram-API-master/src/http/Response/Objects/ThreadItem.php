<?php

namespace InstagramAPI;

class ThreadItem extends Response
{
    public $item_id;
    public $item_type;
    public $text;
    public $user_id;
    public $timestamp;
}
