<?php

namespace InstagramAPI;

class Media extends Response
{
    public $image;
    public $id;
}
