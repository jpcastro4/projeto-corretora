<?php

namespace InstagramAPI;

class RowItem extends Response
{
    public $media_count;
    public $header;
    public $title;
    public $channel_type;
    public $channel_id;
    public $media;
}
