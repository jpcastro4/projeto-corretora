<?php

namespace InstagramAPI;

class HdProfilePicUrlInfo extends Response
{
    public $url;
    public $width;
    public $height;
}
