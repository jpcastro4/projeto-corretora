<?php

namespace InstagramAPI;

class LocationItem extends Response
{
    public $media_bundles;
    public $subtitle;
    /**
     * @var Location
     */
    public $location;
    public $title;
}
