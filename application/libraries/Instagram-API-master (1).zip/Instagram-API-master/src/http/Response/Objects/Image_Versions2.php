<?php

namespace InstagramAPI;

class Image_Versions2 extends Response
{
    /**
     * @var HdProfilePicUrlInfo[]
     */
    public $candidates;
}
