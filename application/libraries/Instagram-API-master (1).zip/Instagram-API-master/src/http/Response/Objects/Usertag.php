<?php

namespace InstagramAPI;

class Usertag extends Response
{
    /**
     * @var In[]
     */
    public $in;
    public $photo_of_you;
}
