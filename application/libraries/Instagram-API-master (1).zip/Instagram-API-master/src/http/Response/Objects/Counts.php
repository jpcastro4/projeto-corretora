<?php

namespace InstagramAPI;

class Counts extends Response
{
    public $relationships;
    public $requests;
    public $photos_of_you;
}
