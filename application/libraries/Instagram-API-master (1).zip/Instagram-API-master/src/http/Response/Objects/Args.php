<?php

namespace InstagramAPI;

class Args extends Response
{
    public $media;
    public $links;
    public $text;
    public $profile_id;
    public $profile_image;
    public $timestamp;
}
