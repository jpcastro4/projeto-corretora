<?php

namespace InstagramAPI;

class Users extends Response
{
    public $position;
    /**
     * @var User
     */
    public $user;
}
