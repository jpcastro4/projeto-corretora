<?php

namespace InstagramAPI;

class Explore extends Response
{
    public $explanation;
    public $actor_id;
    public $source_token;
}
