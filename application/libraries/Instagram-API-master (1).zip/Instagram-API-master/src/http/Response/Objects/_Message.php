<?php

namespace InstagramAPI;

class _Message extends Response
{
    public $key;
    public $time;
}
