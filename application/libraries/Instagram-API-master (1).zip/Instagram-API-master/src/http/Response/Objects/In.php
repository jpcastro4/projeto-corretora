<?php

namespace InstagramAPI;

class In extends Response
{
    /*
     * @var Position
     */
    public $position;
    /*
     * @var User
     */
    public $user;
}
