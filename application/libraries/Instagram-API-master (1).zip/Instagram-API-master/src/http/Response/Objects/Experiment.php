<?php

namespace InstagramAPI;

class Experiment extends Response
{
    /**
     * @var Param[]
     */
    public $params;
    public $group;
    public $name;
}
