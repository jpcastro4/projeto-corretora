<?php

namespace InstagramAPI;

class Insights extends Response
{
    /**
     * @var instagram_insights[]
     */
    public $instagram_insights;
}
