<?php

namespace InstagramAPI;

class Tag extends Response
{
    public $media_count;
    public $name;
    public $id;
}
