<?php

namespace InstagramAPI;

class Link extends Response
{
    public $start;
    public $end;
    public $id;
    public $type;
}
