<?php

namespace InstagramAPI;

class Hashtags extends Response
{
    public $position;
    public $hashtag;
}
