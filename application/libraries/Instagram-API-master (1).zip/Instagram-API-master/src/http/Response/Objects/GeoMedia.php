<?php

namespace InstagramAPI;

class GeoMedia extends Response
{
    public $media_id;
    public $display_url;
    public $low_res_url;
    public $lat;
    public $lng;
    public $thumbnail;
}
