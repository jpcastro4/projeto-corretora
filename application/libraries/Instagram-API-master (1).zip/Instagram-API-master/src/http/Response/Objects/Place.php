<?php

namespace InstagramAPI;

class Place extends Response
{
    public $position;
    /**
     * @var LocationItem
     */
    public $place;
}
