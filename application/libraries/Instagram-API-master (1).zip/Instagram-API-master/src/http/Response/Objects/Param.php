<?php

namespace InstagramAPI;

class Param extends Response
{
    public $name;
    public $value;
}
