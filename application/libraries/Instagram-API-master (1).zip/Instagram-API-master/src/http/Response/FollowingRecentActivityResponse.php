<?php

namespace InstagramAPI;

class FollowingRecentActivityResponse extends Response
{
    public $stories;
    public $next_max_id;
}
