<?php

namespace InstagramAPI;

class CommentLikeUnlikeResponse extends Response
{
}
