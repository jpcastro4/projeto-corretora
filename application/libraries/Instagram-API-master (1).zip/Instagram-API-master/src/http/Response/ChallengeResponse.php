<?php

namespace InstagramAPI;

class ChallengeResponse extends Response
{
    public $status;
}
