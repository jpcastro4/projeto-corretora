<?php

namespace InstagramAPI;

class MediaLikersResponse extends Response
{
    public $user_count;
    /**
     * @var User[]
     */
    public $users;
}
