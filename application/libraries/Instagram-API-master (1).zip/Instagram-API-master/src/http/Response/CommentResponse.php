<?php

namespace InstagramAPI;

class CommentResponse extends Response
{
    public $comment = null;
}
