<?php

namespace InstagramAPI;

class DeleteCommentResponse extends Response
{
}
