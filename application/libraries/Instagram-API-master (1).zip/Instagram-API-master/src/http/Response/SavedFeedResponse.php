<?php

namespace InstagramAPI;

class SavedFeedResponse extends Response
{
    /**
     * @var SavedFeedItem[]
     */
    public $items;
}
