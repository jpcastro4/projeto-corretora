<?php

namespace InstagramAPI;

class UsernameSuggestionsResponse extends Response
{
    public $username_suggestions = null;
}
