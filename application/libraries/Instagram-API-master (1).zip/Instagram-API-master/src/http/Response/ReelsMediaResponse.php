<?php

namespace InstagramAPI;

class ReelsMediaResponse extends Response
{
    /**
     * @var Reel[]
     */
    public $reels_media;

    /**
     * @var Reel[]
     */
    public $reels;
}
