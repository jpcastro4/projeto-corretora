<?php

namespace InstagramAPI;

class MediaDeleteResponse extends Response
{
    public $did_delete;
}
